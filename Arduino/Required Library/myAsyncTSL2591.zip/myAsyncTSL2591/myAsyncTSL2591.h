/*
    AsyncTSL2591.h

    Created by Grégory Marti <greg.marti@gmail.com>
    Copyright 2017 Grégory Marti

    This file is part of the AsyncTSL2591 library.

    AsyncTSL2591 library is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.

    Significant modifications: R Brown, 2020

*/

#ifndef myAsyncTSL2591_H
#define myAsyncTSL2591_H

#include <Arduino.h>

// TSL2591 Integration and gain settings
#define INTEGRATIONTIME_LOW       		0x00     // 100 millis
#define INTEGRATIONTIME_200MS     		0x01     // 200 millis
#define INTEGRATIONTIME_MED       		0x02     // 300 millis
#define INTEGRATIONTIME_400MS     		0x03     // 400 millis
#define INTEGRATIONTIME_HIGH      		0x04     // 500 millis
#define INTEGRATIONTIME_MAX       		0x05     // 600 millis
#define GAIN_LOW                  		0x00     // low gain (1x)
#define GAIN_MED                  		0x10    // medium gain (25x)
#define GAIN_HIGH                 		0x20    // medium gain (428x)
#define GAIN_MAX                  		0x30    // max gain (9876x)

#define TSL2591_I2C_ADDRESS                     0x29
#define TSL2591_LUX_DF                          (408.0F) // Lux cooefficient


// Command register
#define TSL2591_CMD_REGISTER                    0x80
#define TSL2591_CMD_NORMAL_OPERATION            0x20
#define TSL2591_CMD_SPECIAL_FUNCTION            0x30
#define TSL2591_CMD_SP_SET_INTERRUPT            0x04
#define TSL2591_CMD_SP_CLEAR_ALS_INT            0x06
#define TSL2591_CMD_SP_CLEAR_ALS_NO_PERSIST_INT 0x07
#define TSL2591_CMD_SP_CLEAR_NO_PERSIST_INT     0x0A
#define TSL2591_CMD                             0xA0 // TSL2591_CMD_REGISTER | TSL2591_CMD_NORMAL_OPERATION

// Enable register
#define TSL2591_ENABLE_REGISTER                 0x00
#define TSL2591_ENABLE_NPIEN                    0x80
#define TSL2591_ENABLE_SAI                      0x40
#define TSL2591_ENABLE_AIEN                     0x10
#define TSL2591_ENABLE_AEN                      0x02
#define TSL2591_ENABLE_PON                      0x01
#define TSL2591_ENABLE_POF                      0x00

// Control register
#define TSL2591_CONTROL_REGISTER                0x01
#define TSL2591_CONTROL_SRESET                  0x80

typedef enum
{
  TSL2591_GAIN_LOW   = 0x00,
  TSL2591_GAIN_MED   = 0x10,
  TSL2591_GAIN_HIGH  = 0x20,
  TSL2591_GAIN_MAX   = 0x30
}
TSL2591_GAIN;

typedef enum
{
  TSL2591_TIME_100MS = 0x00,
  TSL2591_TIME_200MS = 0x01,
  TSL2591_TIME_300MS = 0x02,
  TSL2591_TIME_400MS = 0x03,
  TSL2591_TIME_500MS = 0x04,
  TSL2591_TIME_600MS = 0x05
}
TSL2591_TIME;

// Persist register
#define TSL2591_PERSIST_REGISTER          0x0C

// PID register
#define TSL2591_PID_REGISTER              0x11
#define TSL2591_PID_PACKAGEID             0x30

// ID register
#define TSL2591_ID_REGISTER               0x12
#define TSL2591_DEVICE_IDENTIFICATION     0x50

// Status register
#define TSL2591_STATUS_REGISTER           0x13
#define TSL2591_STATUS_NPINTR             0x20
#define TSL2591_STATUS_AINT               0x10
#define TSL2591_STATUS_AVALID             0x01

// ALS data register
#define TSL2591_ALSDATA_C0DATAL           0x14    // TSL2591_REGISTER_CHAN0_LOW
#define TSL2591_ALSDATA_C0DATAH           0x15    // TSL2591_REGISTER_CHAN0_HIGH
#define TSL2591_ALSDATA_C1DATAL           0x16    // TSL2591_REGISTER_CHAN1_LOW
#define TSL2591_ALSDATA_C1DATAH           0x17    // TSL2591_REGISTER_CHAN1_HIGH
  
class AsyncTSL2591 {
  public:
    AsyncTSL2591();

    bool begin(TSL2591_GAIN again = TSL2591_GAIN_LOW, TSL2591_TIME atime = TSL2591_TIME_200MS);

    float calculateLux(uint16_t ch0, uint16_t ch1);
    void startLuminosityMeasurement();
    bool isMeasurementReady();
    uint32_t getFullLuminosity();
    void setGain(const TSL2591_GAIN again);
    void setTiming(const TSL2591_TIME atime);
	void poweroff();
    TSL2591_GAIN getGain();
    TSL2591_TIME getTiming();

  private:
    TSL2591_GAIN _again;
    TSL2591_TIME _atime;

    void _updateGainAndTime();
    void _powerOn(uint8_t reg);
    void _powerOff();
    uint8_t _read();
    uint16_t _read16();
    void _write(uint8_t reg);
    void _writeValue(uint8_t reg, uint8_t value);
    uint8_t _readRegister(uint8_t reg);
    uint16_t _readRegister16(uint8_t reg);
};

#endif // AsyncTSL2591_H
