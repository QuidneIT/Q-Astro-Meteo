/*
    AsyncTSL2591.cpp

    Created by Grégory Marti <greg.marti@gmail.com>
    Copyright 2017 Grégory Marti

    This file is part of the AsyncTSL2591 library.

    AsyncTSL2591 library is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.

    Significant modifications: R Brown, 2020

*/

#include <Arduino.h>
#include <Wire.h>
#include "myAsyncTSL2591.h"

AsyncTSL2591::AsyncTSL2591() {}

bool AsyncTSL2591::begin(TSL2591_GAIN again, TSL2591_TIME atime) 
{
  Wire.begin();
  uint8_t id = _readRegister(TSL2591_CMD | TSL2591_ID_REGISTER);

  if (id != TSL2591_DEVICE_IDENTIFICATION) 
  {
    return false;
  }
  _again = again;
  _atime = atime;
  _updateGainAndTime();
  _powerOff();
  return true;
}

float AsyncTSL2591::calculateLux(uint16_t ch0, uint16_t ch1) 
{
  float    atime, again;
  float    cpl, lux;

  // Check for overflow conditions first
  if ((ch0 == 0xFFFF) | (ch1 == 0xFFFF))
  {
    // Signal an overflow
    return -1;
  }

  // Note: This algorithm is based on preliminary coefficients
  // provided by AMS and may need to be updated in the future

  switch (_atime)
  {
    case INTEGRATIONTIME_LOW :
      atime = 100.0F;
      break;
    case INTEGRATIONTIME_200MS :
      atime = 200.0F;
      break;
    case INTEGRATIONTIME_MED :
      atime = 300.0F;
      break;
    case INTEGRATIONTIME_400MS :
      atime = 400.0F;
      break;
    case INTEGRATIONTIME_HIGH :
      atime = 500.0F;
      break;
    case INTEGRATIONTIME_MAX :
      atime = 600.0F;
      break;
    default: // 100ms
      atime = 100.0F;
      break;
  }

  switch (_again)
  {
    case GAIN_LOW :
      again = 1.0F;
      break;
    case GAIN_MED :
      again = 25.0F;
      break;
    case GAIN_HIGH :
      again = 428.0F;
      break;
    case GAIN_MAX :
      again = 9876.0F;
      break;
    default:
      again = 1.0F;
      break;
  }

  cpl = (atime * again) / TSL2591_LUX_DF;
  lux = ( ((float)ch0 - (float)ch1 )) * (1.0F - ((float)ch1/(float)ch0) ) / cpl;

  // I2C had no errors
  return lux;
}

void AsyncTSL2591::poweroff()
{
	_writeValue(TSL2591_CMD | TSL2591_ENABLE_REGISTER, TSL2591_ENABLE_POF);
}

void AsyncTSL2591::setGain(const TSL2591_GAIN again) 
{
  _again = again;
  _updateGainAndTime();
}

void AsyncTSL2591::setTiming(const TSL2591_TIME atime) 
{
  _atime = atime;
  _updateGainAndTime();
}

TSL2591_GAIN AsyncTSL2591::getGain() 
{
  return _again;
}

TSL2591_TIME AsyncTSL2591::getTiming() 
{
  return _atime;
}

void AsyncTSL2591::_updateGainAndTime() 
{
  _writeValue(TSL2591_CMD | TSL2591_CONTROL_REGISTER, _atime | _again);
}

void AsyncTSL2591::_powerOn(uint8_t reg) 
{
  _writeValue(TSL2591_CMD | TSL2591_ENABLE_REGISTER, TSL2591_ENABLE_PON | reg);
}

void AsyncTSL2591::_powerOff() 
{
  _writeValue(TSL2591_CMD | TSL2591_ENABLE_REGISTER, TSL2591_ENABLE_POF);
}

void AsyncTSL2591::startLuminosityMeasurement() 
{
  _powerOn(TSL2591_ENABLE_AEN);
}

uint32_t AsyncTSL2591::getFullLuminosity() 
{
  _powerOff();

  uint32_t x;
  uint16_t y;
  y = _readRegister16(TSL2591_CMD | TSL2591_ALSDATA_C0DATAL);
  x = _readRegister16(TSL2591_CMD | TSL2591_ALSDATA_C1DATAL);
  x <<= 16;
  x |= y;

  return x;
}

bool AsyncTSL2591::isMeasurementReady() 
{
  int reg = _readRegister(TSL2591_CMD | TSL2591_STATUS_REGISTER);
  return reg & TSL2591_STATUS_AVALID;
}

uint8_t AsyncTSL2591::_readRegister(uint8_t reg) 
{
  _write(reg);
  return _read();
}

uint16_t AsyncTSL2591::_readRegister16(uint8_t reg) 
{
  _write(reg);
  return _read16();
}

uint8_t AsyncTSL2591::_read() 
{
  Wire.requestFrom(TSL2591_I2C_ADDRESS, 1);
  return Wire.read();
}

uint16_t AsyncTSL2591::_read16() 
{
  Wire.requestFrom(TSL2591_I2C_ADDRESS, 2);
  uint16_t result;
  result = Wire.read();
  result |= Wire.read() << 8;
  return result;
}

void AsyncTSL2591::_write(uint8_t reg) 
{
  Wire.beginTransmission(TSL2591_I2C_ADDRESS);
  Wire.write(reg);
  Wire.endTransmission(true);
}

void AsyncTSL2591::_writeValue(uint8_t reg, uint8_t value) 
{
  Wire.beginTransmission(TSL2591_I2C_ADDRESS);
  Wire.write(reg);
  Wire.write(value);
  Wire.endTransmission(true);
}
