# Adafruit BME280 MODIFIED Library 

<a href="http://www.adafruit.com/products/2652"><img src="./assets/board.jpg" width="500"/></a>

This is a MODIFIED library for the Adafruit BME280 Humidity, Barometric Pressure + Temp sensor
The only line modified is:
From #define BME280_ADDRESS (0x77) to #define BME280_ADDRESS (0x76)


Designed specifically to work with the Adafruit BME280 Breakout 
 * http://www.adafruit.com/products/2652

These sensors use I2C to communicate

Adafruit invests time and resources providing this open source code, 
please support Adafruit and open-source hardware by purchasing 
products from Adafruit!

Written by Limor Fried/Ladyada for Adafruit Industries.  
BSD license, all text above must be included in any redistribution

Place the Adafruit_BME280 library folder your arduinosketchfolder/libraries/ folder. 
You may need to create the libraries subfolder if its your first library. Restart the IDE.

We also have a great tutorial on Arduino library installation at:
http://learn.adafruit.com/adafruit-all-about-arduino-libraries-install-use
